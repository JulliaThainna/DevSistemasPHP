<?php
require_once "./dao/ConnectionFactory.php";
require_once "./model/Fabricante.php";
require_once "./dao/FabricanteDao.php";

$fabricanteDao = new FabricanteDao();

include "view/fabricante.php"
?>