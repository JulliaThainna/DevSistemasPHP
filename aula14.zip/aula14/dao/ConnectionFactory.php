<?php
class ConnectionFactory{
    static $conn;

    public static function getConnection(){
        if(!isset($conn)){ //Tá vazia? Se sim ...
            $database = "test"; // Coloque o nome do seu bd
            $user = "root";
            $pass = "";
            $host = "localhost";
            $port = "3307"; // Na faculdade MySQL do XAMPP é 3307
            try{
                $conn = new PDO("mysql:host=$host;port=$port;dbname=$database", $user, $pass);
                //echo "conectado";
                return $conn;
            }catch(PDOException $ex){ //Classe de tratamento SQL no php
                echo "Erro! ". $ex->getMessage();
                return null;
            }
        } // Se não...
        return $conn;
    }
}
?>