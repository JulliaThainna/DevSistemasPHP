<?php
class FabricanteDao{
    public function inserir(Fabricante $fab){
        try{
            $sql = "INSERT INTO fabricante (nome, endereco, documento) values (:nome, :endereco, :documento);";
            $conn = ConnectionFactory::getConnection()->prepare($sql); 
            $conn->bindValue(":nome", $fab->getNome());
            $conn->bindValue(":endereco", $fab->getEndereco());
            $conn->bindValue(":documento", $fab->getDocumento());
            return $conn->execute();
        }catch(Exception $e){
            print "<p>Erro ao inserir Fabricante</p> $e";
        }

    }

    public function listar(){
        try{
            $sql = "SELECT * FROM fabricante";
            $result = ConnectionFactory::getConnection()->query($sql);
            $lista = $result->fetchAll(PDO::FETCH_ASSOC); //"Matriz"
            foreach($lista as $l){
                $fab_lista[] = $this->listarFabricante($l);
            }
            return $fab_lista;
        }catch(Exception $e){
            echo "Erro ao listar Fabricantes". $e->getMessage();
        }
    }

    public function listarFabricante($row){
        $fabricante = new Fabricante();
        $fabricante->setId($row['id']);
        $fabricante->setNome($row['nome']);
        $fabricante->setEndereco($row['endereco']);
        $fabricante->setDocumento($row['documento']);

        return $fabricante;
    }
}
?>