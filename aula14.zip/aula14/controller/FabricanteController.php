<?php
require_once "../dao/ConnectionFactory.php";
require_once "../model/Fabricante.php";
require_once "../dao/FabricanteDao.php";

$fabricante = new Fabricante();
$fabricanteDao = new FabricanteDao();

$dataPost = filter_input_array(INPUT_POST);

if(isset($_POST['cadastrar'])){
    $fabricante->setNome($dataPost['nome']);
    $fabricante->setEndereco($dataPost['endereco']);
    $fabricante->setDocumento($dataPost['documento']);
    $fabricanteDao->inserir($fabricante);
    header("Location: ../FabricanteForm.php");
}
?>